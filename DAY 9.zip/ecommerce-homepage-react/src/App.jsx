import { useState } from "react";

export default function App() {
  const [cart, setCart] = useState([]);
const [showCart, setShowCart] = useState(false);
const totalPrice = cart.reduce(
  (total, item) => total + item.price,
  0
);
const removeFromCart = (indexToRemove) => {
  setCart(
    cart.filter((_, index) => index !== indexToRemove)
  );
};
  const [search, setSearch] = useState("");

  const products = [
    {
      name: "Watch",
      image: "/images/1.jpg",
      price: "1999"
    },
    {
      name: "Backpack",
      image: "/images/2.jpg",
      price: "599"
    },
    {
      name: "Shoes",
      image: "/images/3.jpg",
      price: "999"
    },
    {
      name: "Shirt",
      image: "/images/4.jpg",
      price: "499"
    }
  ];

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(search.toLowerCase())
  );
if (showCart) {
  return (
    <div>

      {/* Navbar */}
      <header className="navbar">

        <div className="logo">
          <img
            src="/images/logo.png"
            alt="Shoply Logo"
            className="logo-img"
          />
          <h2>Shoply</h2>
        </div>

      

        <div className="nav-icons">
          <button
            className="cart-btn-nav"
            onClick={() => setShowCart(false)}
          >
            🏠 Home
          </button>
        </div>

      </header>

      {/* Cart Page */}
     <div className="cart-page">

  <h1>🛒 My Cart</h1>

  {cart.length === 0 ? (
    <h2>Your cart is empty 😔</h2>
  ) : (
    <>
      {cart.map((item, index) => (
        <div key={index} className="cart-item">

          <img
            src={item.image}
            alt={item.name}
            className="cart-image"
          />

          <div className="cart-details">
            <h3>{item.name}</h3>
            <p>₹{item.price}</p>

            <button
              className="delete-btn"
              onClick={() => removeFromCart(index)}
            >
              Delete
            </button>
          </div>

        </div>
      ))}

      <div className="cart-summary">
        <h2>Total: ₹{totalPrice}</h2>

        <button
          className="empty-cart-btn"
          onClick={() => setCart([])}
        >
          Empty Cart
        </button>
      </div>
    </>
  )}

</div>

    </div>
  );
}

  return (
    <div>

      {/* Navbar */}
      <header className="navbar">

        <div className="logo">
          <img
            src="/images/logo.png"
            alt="Shoply Logo"
            className="logo-img"
          />
          <h2>Shoply</h2>
        </div>

        <nav className="nav-links">
          <a href="#">Home</a>
          <a href="#">Shop</a>
          <a href="#">Categories</a>
          <a href="#">Deals</a>
          <a href="#">Contact</a>
        </nav>

        <div className="nav-icons">

          <input
            type="text"
            placeholder="Search products..."
            className="search-box"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <button
  className="cart-btn-nav"
  onClick={() => setShowCart(true)}
>
  🛒 Cart ({cart.length})
</button>

        </div>

      </header>

      {/* Hero Section */}
      <section className="hero">

        <div>
          <h1>Elevate Your Style This Summer</h1>

          <p>
            Discover premium fashion, accessories,
            and lifestyle products at unbeatable prices.
          </p>

          <button>
            Shop Now
          </button>
        </div>

      </section>

      {/* Featured Products */}
      <section className="featured">

        <h2>Featured Products</h2>

        <div className="grid">

          {filteredProducts.length > 0 ? (
            filteredProducts.map((p, i) => (

              <div key={i} className="card">

                <img
                  src={p.image}
                  alt={p.name}
                  className="img"
                />

                <h3>{p.name}</h3>

                <p>{p.price}</p>

               <button
  className="cart-btn"
  onClick={() => setCart([...cart, p])}
>
  Add to Cart
</button>
              </div>

            ))
          ) : (
            <h3>😔 No products found</h3>
          )}

        </div>

      </section>

    </div>
  );
}