export default function Contact() {
  return (
    <div
      style={{
        minHeight: "80vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        background: "#f5f5f5",
        padding: "40px"
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: "1000px",
          background: "#fff",
          display: "flex",
          borderRadius: "20px",
          overflow: "hidden",
          boxShadow: "0 10px 30px rgba(0,0,0,0.1)"
        }}
      >
        <div
          style={{
            flex: 2,
            padding: "40px",
            display: "flex",
            flexDirection: "column",
            gap: "15px"
          }}
        >
          <h1>Contact Us</h1>

          <input type="text" placeholder="Your Name" />

          <input type="email" placeholder="Your Email" />

          <textarea rows="5" placeholder="Your Message"></textarea>

          <button
  onClick={() => {
    setMessageSent(true);

    setTimeout(() => {
      setMessageSent(false);
    }, 3000);
  }}
>
  Send Message
</button>
{messageSent && (
  <div className="success-popup">
    ✅ Message Sent okkkkk Successfully!
  </div>
)}
        </div>

        <div
          style={{
            flex: 1,
            background: "#faf7f8",
            padding: "40px",
            textAlign: "center"
          }}
        >
          <img
            src="/images/logo.png"
            alt="logo"
            style={{ width: "120px" }}
          />

          <h2>Shoply</h2>

          <p>📍 Hyderabad, India</p>
          <p>📞 +91 9876543210</p>
          <p>📧 support@shoply.com</p>
        </div>
      </div>
    </div>
  );
}