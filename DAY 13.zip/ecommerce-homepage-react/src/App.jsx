import { useState } from "react";


export default function App() {
  const [cart, setCart] = useState([]);
const [showCart, setShowCart] = useState(false);
const [showAbout, setShowAbout] = useState(false);
const [messageSent, setMessageSent] = useState(false);
const [showCheckout, setShowCheckout] = useState(false);
const [orderPlaced, setOrderPlaced] = useState(false);
const [wishlist, setWishlist] = useState([]);
const [showWishlist, setShowWishlist] = useState(false);
const [showDeals, setShowDeals] = useState(false);

const totalPrice = cart.reduce(
  (total, item) =>
    total + item.price * item.quantity,
  0
);
const removeFromCart = (indexToRemove) => {
  setCart(
    cart.filter((_, index) => index !== indexToRemove)
  );
};
  const [search, setSearch] = useState("");
  const [selectedProduct, setSelectedProduct] = useState(null);
const [showContact, setShowContact] = useState(false);
  const products = [
  {
    name: "Watch",
    image: "/images/1.jpg",
    price: 1999,
    rating: 4.8
  },
  {
    name: "Backpack",
    image: "/images/2.jpg",
    price: 599,
    rating: 4.5
  },
  {
    name: "Shoes",
    image: "/images/3.jpg",
    price: 999,
    rating: 4.7
  },
  {
    name: "Shirt",
    image: "/images/4.jpg",
    price: 499,
    rating: 4.3
  },
  {
    name: "Gaming Keyboard",
    image: "/images/5.jpg",
    price: 999,
    rating: 4.9
  },
  {
    name: "Gaming Mouse",
    image: "/images/6.jpg",
    price: 699,
    rating: 4.6
  },
  {
    name: "Bellavita GiftSet Perfume",
    image: "/images/7.jpg",
    price: 799,
    rating: 4.9
  },
  {
    name: "Slovic Cricket Bat",
    image: "/images/8.jpg",
    price: 299,
    rating: 4.5
  },
  {
    name: "Slovic Fotball",
    image: "/images/9.jpg",
    price: 499,
    rating: 4.8
  },
  {
    name: "Water Bottle",
    image: "/images/10.jpg",
    price: 499,
    rating: 4.4
  },
  {
    name: "DOMS haary potter book",
    image: "/images/11.jpg",
    price: 699,
    rating: 4.8
  },
  {
    name: "Vega General Scissor Set of 2",
    image: "/images/12.jpg",
    price: 499,
    rating: 4.9
  }
];

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(search.toLowerCase())
  );
  if (showAbout) {
  return (
    <div>

      <header className="navbar">

        <div className="logo">
          <img
            src="/images/logo.png"
            alt="Shoply Logo"
            className="logo-img"
          />
          <h2>Shoply</h2>
        </div>

        <button
          className="cart-btn-nav"
          onClick={() => setShowAbout(false)}
        >
          🏠 Home
        </button>

      </header>

      <div className="about-page">

        <div className="about-container">

          <div className="about-left">

            <img
              src="/images/logo.png"
              alt="Shoply"
              className="about-logo"
            />

          </div>

          <div className="about-right">

            <h1>About Shoply</h1>

            <p>
              Welcome to Shoply, your trusted online
              shopping destination. We provide premium
              products at affordable prices with fast
              delivery and excellent customer service.
            </p>

            <p>
              Our mission is to make online shopping
              simple, secure, and enjoyable for everyone.
            </p>

            <p>
              Founded in 2025, Shoply serves customers
              across India with quality products and
              unbeatable deals.
            </p>

            <div className="about-stats">

              <div>
                <h2>10K+</h2>
                <p>Happy Customers</p>
              </div>

              <div>
                <h2>500+</h2>
                <p>Products</p>
              </div>

              <div>
                <h2>24/7</h2>
                <p>Support</p>
              </div>

            </div>

          </div>

        </div>

      </div>

    </div>
  );
}
  if (showContact) {
  return (
    <div>

      <header className="navbar">

        <div className="logo">
          <img
            src="/images/logo.png"
            alt="Shoply Logo"
            className="logo-img"
          />
          <h2>Shoply</h2>
        </div>

        <button
          className="cart-btn-nav"
          onClick={() => setShowContact(false)}
        >
          🏠 Home
        </button>

      </header>

      <div className="contact-page">

        <div className="contact-box">

          <div className="contact-left">

            <h1>Contact Us</h1>

            <p>
              We'd love to hear from you.
              Send us a message and we'll respond as soon as possible.
            </p>

            <input
              type="text"
              placeholder="Your Name"
            />

            <input
              type="email"
              placeholder="Your Email"
            />

            <textarea
              rows="5"
              placeholder="Your Message"
            ></textarea>

            <button
  onClick={() => {
    setMessageSent(true);

    setTimeout(() => {
      setMessageSent(false);
    }, 3000);
  }}
>
  Send Message
</button>
{messageSent && (
  <div className="success-popup">
    ✅ Message Sent Successfully!
  </div>
)}
          </div>

          <div className="contact-right">

            <img
              src="/images/logo.png"
              alt="Shoply"
              className="contact-logo"
            />

            <h2>Shoply</h2>

            <p>📍 Palitana, India</p>

            <p>📞 +91 70464049484</p>

            <p>📧 support@shoply.com</p>

            <p>🕒 Mon - Sat | 9AM - 8PM</p>

          </div>

        </div>

      </div>

    </div>
  );
}
  if (selectedProduct) {
  return (
    <div>

      <header className="navbar">

  <div className="logo">
    <img
      src="/images/logo.png"
      alt="Shoply Logo"
      className="logo-img"
    />
    <h2>Shoply</h2>
  </div>

  <div className="nav-icons">

    <button
      className="wishlist-btn-nav"
      onClick={() => setShowWishlist(true)}
    >
      ❤️ Wishlist ({wishlist.length})
    </button>

    <button
      className="cart-btn-nav"
      onClick={() => setShowCart(true)}
    >
      🛒 Cart ({cart.length})
    </button>

    <button
      className="cart-btn-nav"
      onClick={() => setSelectedProduct(null)}
    >
      ← Back
    </button>

  </div>

</header>

      <div className="product-page">

        <img
          src={selectedProduct.image}
          alt={selectedProduct.name}
          className="product-page-image"
        />

       <h1>{selectedProduct.name}</h1>

<h2>₹{selectedProduct.price}</h2>

<div className="rating">
  {"⭐".repeat(Math.round(selectedProduct.rating))}
  <span> ({selectedProduct.rating})</span>
</div>

<p>
  Premium quality product with modern design,
  excellent durability and fast delivery.
</p>

<button
  className="wishlist-btn"
  onClick={() => {
    if (
      !wishlist.find(
        item =>
          item.name === selectedProduct.name
      )
    ) {
      setWishlist([
        ...wishlist,
        selectedProduct
      ]);
    }
  }}
>
  ❤️ Add To Wishlist
</button>

<button
  className="cart-btn"
  onClick={() => {
    const existingProduct = cart.find(
      item =>
        item.name === selectedProduct.name
    );

    if (existingProduct) {
      setCart(
        cart.map(item =>
          item.name === selectedProduct.name
            ? {
                ...item,
                quantity: item.quantity + 1
              }
            : item
        )
      );
    } else {
      setCart([
        ...cart,
        {
          ...selectedProduct,
          quantity: 1
        }
      ]);
    }
  }}
>
  🛒 Add To Cart
</button>

      </div>

    </div>
  );
}
if (orderPlaced) {
  return (
    <div>

      <header className="navbar">

        <div className="logo">
          <img
            src="/images/logo.png"
            alt="Shoply Logo"
            className="logo-img"
          />
          <h2>Shoply</h2>
        </div>

      </header>

      <div className="success-page">

        <div className="success-card">

          <h1>🎉 Order Placed Successfully!</h1>

          <h3>Thank you for shopping with Shoply</h3>

          <p>
            Your order has been confirmed and will
            be delivered soon.
          </p>

          <button
            onClick={() => {
              setOrderPlaced(false);
              setShowCheckout(false);
              setShowCart(false);
              setCart([]);
            }}
          >
            Continue Shopping
          </button>

        </div>

      </div>

    </div>
  );
}
if (showCheckout) {
  return (
    <div>

      <header className="navbar">

        <div className="logo">
          <img
            src="/images/logo.png"
            alt="Shoply Logo"
            className="logo-img"
          />
          <h2>Shoply</h2>
        </div>

        <button
          className="cart-btn-nav"
          onClick={() => setShowCheckout(false)}
        >
          🏠 Home
        </button>

      </header>

      <div className="checkout-page">

        <div className="checkout-container">

          <h1>Checkout</h1>

          <input
            type="text"
            placeholder="Full Name"
          />

          <input
            type="email"
            placeholder="Email Address"
          />

          <input
            type="text"
            placeholder="Phone Number"
          />

          <textarea
            rows="4"
            placeholder="Shipping Address"
          ></textarea>

          <h2>Total: ₹{totalPrice}</h2>

         <button
  onClick={() => setOrderPlaced(true)}
>
  Place Order
</button>

        </div>

      </div>

    </div>
  );
}
if (showDeals) {

  const dealProducts = [
    {
      name: "Watch",
      image: "/images/1.jpg",
      oldPrice: 2999,
      price: 1999,
      rating: 4.8
    },
    {
      name: "Shoes",
      image: "/images/3.jpg",
      oldPrice: 1499,
      price: 999,
      rating: 4.7
    },
    {
      name: "Gaming Mouse",
      image: "/images/6.jpg",
      oldPrice: 999,
      price: 699,
      rating: 4.6
    },
    {
      name: "DOMS harry potter book",
      image: "/images/11.jpg",
      oldPrice: 699,
      price: 499,
      rating: 4.8
    },
  ];

  return (
    <div>

      <header className="navbar">

        <div className="logo">
          <img
            src="/images/logo.png"
            alt="Shoply Logo"
            className="logo-img"
          />
          <h2>Shoply</h2>
        </div>

        <button
          className="cart-btn-nav"
          onClick={() => setShowDeals(false)}
        >
          🏠 Home
        </button>

      </header>

      <div className="deals-page">

        <h1>🔥 Today's Deals</h1>

        <div className="grid">

          {dealProducts.map((item, index) => (

            <div
              key={index}
              className="card"
            >

              <img
                src={item.image}
                alt={item.name}
                className="img"
              />

              <h3>{item.name}</h3>

              <div className="rating">
                {"⭐".repeat(Math.round(item.rating))}
              </div>

              <p className="old-price">
                ₹{item.oldPrice}
              </p>

              <p className="deal-price">
                ₹{item.price}
              </p>

              <span className="deal-badge">
                SALE
              </span>

              {/* Wishlist */}
              <button
                className="wishlist-btn"
                onClick={() => {
                  if (
                    !wishlist.find(
                      product =>
                        product.name === item.name
                    )
                  ) {
                    setWishlist([
                      ...wishlist,
                      {
                        ...item,
                        quantity: 1
                      }
                    ]);
                  }
                }}
              >
                ❤️ Wishlist
              </button>

              {/* Cart */}
              <button
                className="cart-btn"
                onClick={() => {

                  const existingProduct =
                    cart.find(
                      product =>
                        product.name === item.name
                    );

                  if (existingProduct) {
                    setCart(
                      cart.map(product =>
                        product.name === item.name
                          ? {
                              ...product,
                              quantity:
                                product.quantity + 1
                            }
                          : product
                      )
                    );
                  } else {
                    setCart([
                      ...cart,
                      {
                        ...item,
                        quantity: 1
                      }
                    ]);
                  }

                }}
              >
                🛒 Add To Cart
              </button>

              {/* Buy Now */}
              <button
                className="checkout-btn"
                onClick={() => {

                  setCart([
                    {
                      ...item,
                      quantity: 1
                    }
                  ]);

                  setShowDeals(false);
                  setShowCheckout(true);

                }}
              >
                ⚡ Buy Now
              </button>

            </div>

          ))}

        </div>

      </div>

    </div>
  );
}
if (showWishlist) {
  return (
    <div>

      <header className="navbar">

        <div className="logo">
          <img
            src="/images/logo.png"
            alt="Shoply Logo"
            className="logo-img"
          />
          <h2>Shoply</h2>
        </div>

        <div className="nav-icons">

          <button
            className="cart-btn-nav"
            onClick={() => setShowWishlist(false)}
          >
            🏠 Home
          </button>

          <button
            className="cart-btn-nav"
            onClick={() => setShowCart(true)}
          >
            🛒 Cart ({cart.length})
          </button>

        </div>

      </header>

      <div className="wishlist-page">

        <h1>❤️ My Wishlist</h1>

        {wishlist.length === 0 ? (
          <h2>No products in wishlist 😔</h2>
        ) : (
          wishlist.map((item, index) => (
            <div
              key={index}
              className="wishlist-item"
            >

              <img
                src={item.image}
                alt={item.name}
                className="cart-image"
              />

              <div className="cart-details">

                <h3>{item.name}</h3>

                <p>₹{item.price}</p>

                {/* Move To Cart */}
                <button
                  className="cart-btn"
                  onClick={() => {

                    const existingProduct =
                      cart.find(
                        product =>
                          product.name === item.name
                      );

                    if (existingProduct) {
                      setCart(
                        cart.map(product =>
                          product.name === item.name
                            ? {
                                ...product,
                                quantity:
                                  product.quantity + 1
                              }
                            : product
                        )
                      );
                    } else {
                      setCart([
                        ...cart,
                        {
                          ...item,
                          quantity: 1
                        }
                      ]);
                    }

                  }}
                >
                  🛒 Move To Cart
                </button>

                {/* Buy Now */}
                <button
                  className="checkout-btn"
                  onClick={() => {
                    setCart([
                      {
                        ...item,
                        quantity: 1
                      }
                    ]);

                    setShowWishlist(false);
                    setShowCheckout(true);
                  }}
                >
                  ⚡ Buy Now
                </button>

                {/* Remove */}
                <button
                  className="delete-btn"
                  onClick={() =>
                    setWishlist(
                      wishlist.filter(
                        (_, i) => i !== index
                      )
                    )
                  }
                >
                  ❌ Remove
                </button>

              </div>

            </div>
          ))
        )}

      </div>

    </div>
  );
}
if (showCart) {
  return (
    <div>

      {/* Navbar */}
      <header className="navbar">

        <div className="logo">
          <img
            src="/images/logo.png"
            alt="Shoply Logo"
            className="logo-img"
          />
          <h2>Shoply</h2>
        </div>
<a
    href="#"
    onClick={() => setShowAbout(true)}
>
  About Us
</a>
        <div className="nav-icons">
          
          <button
            className="cart-btn-nav"
            onClick={() => setShowCart(false)}
          >
            🏠 Home
          </button>
          
        </div>

      </header>

      {/* Cart Page */}
     <div className="cart-page">

  <h1>🛒 My Cart</h1>

  {cart.length === 0 ? (
    <h2>Your cart is empty 😔</h2>
  ) : (
    <>
      {cart.map((item, index) => (
        <div key={index} className="cart-item">

          <img
            src={item.image}
            alt={item.name}
            className="cart-image"
          />

          <div className="cart-details">
            <h3>{item.name}</h3>
            <p>₹{item.price}</p>

<div className="quantity-box">

  <button
    onClick={() =>
      setCart(
        cart.map((cartItem, i) =>
          i === index
            ? {
                ...cartItem,
                quantity:
                  cartItem.quantity > 1
                    ? cartItem.quantity - 1
                    : 1
              }
            : cartItem
        )
      )
    }
  >
    -
  </button>

  <span>{item.quantity}</span>

  <button
    onClick={() =>
      setCart(
        cart.map((cartItem, i) =>
          i === index
            ? {
                ...cartItem,
                quantity:
                  cartItem.quantity + 1
              }
            : cartItem
        )
      )
    }
  >
    +
  </button>

</div>

<h4>
  Subtotal:
  ₹{item.price * item.quantity}
</h4>

            <button
              className="delete-btn"
              onClick={() => removeFromCart(index)}
            >
              Delete
            </button>
          </div>

        </div>
      ))}

     <div className="cart-summary">

  <h2>Total: ₹{totalPrice}</h2>

  <button
    className="checkout-btn"
    onClick={() => setShowCheckout(true)}
  >
    Proceed To Checkout
  </button>

  <button
    className="empty-cart-btn"
    onClick={() => setCart([])}
  >
    Empty Cart
  </button>

</div>
    </>
  )}

</div>

    </div>
  );
}

  return (
    <div>

      {/* Navbar */}
      <header className="navbar">

        <div className="logo">
          <img
            src="/images/logo.png"
            alt="Shoply Logo"
            className="logo-img"
          />
          <h2>Shoply</h2>
        </div>

       <nav className="nav-links">

  <a href="#">Home</a>
  <a
    href="#"
    onClick={() => setShowDeals(true)}
  >
    Deals
  </a>

  <a
    href="#"
    onClick={() => setShowContact(true)}
  >
    Contact
  </a>

  <a
    href="#"
    onClick={() => setShowAbout(true)}
>
  About Us
</a>

</nav>

        <div className="nav-icons">

          <input
            type="text"
            placeholder="Search products..."
            className="search-box"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
<button
  className="wishlist-btn-nav"
  onClick={() => setShowWishlist(true)}
>
  ❤️ Wishlist ({wishlist.length})
</button>
          <button
  className="cart-btn-nav"
  onClick={() => setShowCart(true)}
>
  🛒 Cart ({cart.length})
</button>

        </div>

      </header>

      {/* Hero Section */}
      <section className="hero">

        <div>
          <h1>Elevate Your Style This Summer</h1>

          <p>
            Discover premium fashion, accessories,
            and lifestyle products at unbeatable prices.
          </p>

          <button>
            Shop Now
          </button>
        </div>

      </section>

      {/* Featured Products */}
      <section className="featured">

        <h2>Featured Products</h2>

        <div className="grid">

          {filteredProducts.length > 0 ? (
            filteredProducts.map((p, i) => (

              <div key={i} className="card">

                <img
                  src={p.image}
                  alt={p.name}
                  className="img"
                />

                <h3>{p.name}</h3>

<div className="rating">
  {"⭐".repeat(Math.round(p.rating))}
  <span> ({p.rating})</span>
</div>

<p>₹{p.price}</p>

<button
  className="view-btn"
  onClick={() => setSelectedProduct(p)}
>
  View Product
</button>
<button
  className="wishlist-btn"
  onClick={() => {
    if (
      !wishlist.find(
        item => item.name === p.name
      )
    ) {
      setWishlist([
        ...wishlist,
        {
          ...p,
          quantity: 1
        }
      ]);
    }
  }}
>
  ❤️ Add To Wishlist
</button>
<button
  className="cart-btn"
  onClick={() => {
  const existingProduct = cart.find(
    item => item.name === p.name
  );

  if (existingProduct) {
    setCart(
      cart.map(item =>
        item.name === p.name
          ? {
              ...item,
              quantity: item.quantity + 1
            }
          : item
      )
    );
  } else {
    setCart([
      ...cart,
      {
        ...p,
        quantity: 1
      }
    ]);
  }
}}
>
  Add To Cart
</button>
              </div>

            ))
          ) : (
            <h3>😔 No products found</h3>
          )}

        </div>

      </section>

    </div>
  );
}