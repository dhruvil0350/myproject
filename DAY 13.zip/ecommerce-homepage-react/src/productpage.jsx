import { Link } from "react-router-dom";

export default function ProductPage() {
return ( <div className="product-page">

```
  <Link to="/">
    <button className="back-btn">
      ← Back to Home
    </button>
  </Link>

  <div className="product-card">

    <img
      src="/images/1.jpg"
      alt="Product"
      className="product-img"
    />

    <div className="product-info">

      <h1>Premium Watch</h1>

      <h2>₹1999</h2>

      <p>
        Premium quality watch with stylish design
        and long battery life.
      </p>
      <button
  className="wishlist-btn"
  onClick={() => {
    if (
      !wishlist.find(
        item => item.name === p.name
      )
    ) {
      setWishlist([...wishlist, p]);
    }
  }}
>
   Wishlist
</button>

      <div className="product-buttons">
        <button className="add-btn">
          Add To Cart
        </button>

        <button className="buy-btn">
          Buy Now
        </button>
      </div>

    </div>

  </div>

</div>

);
}
