import "./product.css";

const products = [
  {
    id: 1,
    image: "/images/1.png",
    name: "White Shoes",
    price: "599",
    color: "White & Blue",
  },
  {
    id: 2,
    image: "/images/2.jpg",
    name: "Light Blue Classic Shirt",
    price: "299",
    oldPrice: "399",
    color: "LIGHT BLUE",
  },
  {
    id: 3,
    image: "/images/5.jpg",
    name: "Men's Dark Grey Mufti Jeans",
    price: "499",
    color: "DARK GREY",
  },
];

export default function Products() {
  const addToCart = (product) => {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];

    cart.push(product);

    localStorage.setItem("cart", JSON.stringify(cart));

    alert(`${product.name} added to cart!`);
  };

  return (
    <div className="buy-look-section">
      <h2>BUY THE LOOK</h2>

      <div className="products-container">
        {products.map((product) => (
          <div className="product-card" key={product.id}>
            <div className="image-box">
              <img src={product.image} alt={product.name} />

              <button className="wishlist">
                ♡
              </button>
            </div>

            <div className="product-info">
              <h4>{product.name}</h4>

              {product.oldPrice && (
                <p className="old-price">
                  ₹{product.oldPrice}
                </p>
              )}

              <p className="price">
                ₹{product.price}
              </p>

              <p className="color">
                {product.color}
              </p>

              <select>
                <option>Please Select</option>
                <option>S</option>
                <option>M</option>
                <option>L</option>
                <option>XL</option>
              </select>

              <button
                className="add-btn"
                onClick={() => addToCart(product)}
              >
                ADD TO CART
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}