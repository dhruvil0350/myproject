
import {Link} from 'react-router-dom';
export default ()=> <nav className='nav'><h2>ShopX</h2><div><Link to='/'>Home</Link> <Link to='/products'>Products</Link> <Link to='/cart'>Cart</Link></div></nav>;
import { Link } from "react-router-dom";

<Link to="/cart">Cart</Link>