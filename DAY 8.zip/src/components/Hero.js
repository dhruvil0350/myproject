import { Link } from "react-router-dom";

export default function Hero() {
  return (
    <section className="hero">
      <div>
        <span className="badge">🔥 New Collection 2025</span>

        <h1>Discover The Latest Fashion & Electronics</h1>

        <p>Premium products with exclusive discounts.</p>

        <Link to="/products">
          <button>Shop Now</button>
        </Link>
      </div>

      <div className="mockups">
        <div>🎧</div>
        <div>👕</div>
        <div>👟</div>
      </div>
    </section>
  );
}