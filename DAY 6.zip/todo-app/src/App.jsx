import React, { useState } from "react";
import Header from "./components/Header";
import TaskForm from "./components/TaskForm";
import TaskList from "./components/TaskList";
import Footer from "./components/Footer";
import "./App.css";

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [editTask, setEditTask] = useState(null);

  const addTask = (text) => {
    setTasks([...tasks, {
      id: Date.now(),
      text,
      completed: false,
      createdAt: new Date().toLocaleString()
    }]);
  };

  const updateTask = (text) => {
    setTasks(tasks.map(t => t.id === editTask.id ? {...t, text} : t));
    setEditTask(null);
  };

  const deleteTask = (id) => setTasks(tasks.filter(t => t.id !== id));
  const toggleComplete = (id) =>
    setTasks(tasks.map(t => t.id === id ? {...t, completed: !t.completed} : t));

  const completed = tasks.filter(t => t.completed).length;
  const pending = tasks.length - completed;

  return (
    <div className="container">
      <Header />
      <TaskForm addTask={addTask} updateTask={updateTask} editTask={editTask} />
      <TaskList tasks={tasks} deleteTask={deleteTask} toggleComplete={toggleComplete} setEditTask={setEditTask} />
      <Footer total={tasks.length} completed={completed} pending={pending} clearAllTasks={() => setTasks([])} />
    </div>
  );
}
