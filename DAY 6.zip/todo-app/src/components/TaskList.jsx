import TaskItem from "./TaskItem";
export default function TaskList({tasks,...props}){
 if(!tasks.length) return <div className="empty-message">No tasks available.</div>;
 return <div>{tasks.map(t=><TaskItem key={t.id} task={t} {...props}/> )}</div>
}