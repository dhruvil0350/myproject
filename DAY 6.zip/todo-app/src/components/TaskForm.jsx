import {useState,useEffect} from "react";
export default function TaskForm({addTask,updateTask,editTask}){
 const [task,setTask]=useState("");
 useEffect(()=>{ if(editTask) setTask(editTask.text); },[editTask]);
 const submit=e=>{e.preventDefault(); if(!task.trim()) return; editTask?updateTask(task):addTask(task); setTask("");};
 return <form className="task-form" onSubmit={submit}>
 <input value={task} onChange={e=>setTask(e.target.value)} placeholder="Enter task"/>
 <button>{editTask?"Update":"Add Task"}</button>
 </form>
}