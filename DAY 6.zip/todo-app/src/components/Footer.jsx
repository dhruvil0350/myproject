export default function Footer({total,completed,pending,clearAllTasks}){
 return <div className="footer">
 <p>Total: {total}</p><p>Completed: {completed}</p><p>Pending: {pending}</p>
 <button onClick={clearAllTasks}>Clear All</button>
 </div>
}