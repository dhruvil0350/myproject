export default function TaskItem({task,deleteTask,toggleComplete,setEditTask}){
 return <div className={task.completed?"task-item completed":"task-item"}>
 <div><h3>{task.text}</h3><p>{task.completed?"Completed":"Pending"}</p><small>{task.createdAt}</small></div>
 <div><button onClick={()=>toggleComplete(task.id)}>✓</button><button onClick={()=>setEditTask(task)}>Edit</button><button onClick={()=>deleteTask(task.id)}>Delete</button></div>
 </div>
}