
import {useEffect,useState} from 'react';
export default function EmployeeForm({onSave,editing}){
  const [form,setForm]=useState({id:'',name:'',department:'',designation:'',salary:''});
  useEffect(()=>{ if(editing) setForm(editing); },[editing]);
  const submit=e=>{
    e.preventDefault();
    if(Object.values(form).some(v=>!v)){ alert('All fields required'); return; }
    onSave(form);
    setForm({id:'',name:'',department:'',designation:'',salary:''});
  };
  return <form onSubmit={submit}>
    {['id','name','department','designation','salary'].map(k=>
      <input key={k} placeholder={k.toUpperCase()} value={form[k]} onChange={e=>setForm({...form,[k]:e.target.value})}/>)}
    <button>{editing?'Update':'Add'} Employee</button>
  </form>
}
