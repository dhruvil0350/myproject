
export default function EmployeeTable({employees,onEdit,onDelete}){
  if(!employees.length) return <p>No employee records available.</p>;
  return <table>
  <thead><tr><th>ID</th><th>Name</th><th>Department</th><th>Designation</th><th>Salary</th><th>Actions</th></tr></thead>
  <tbody>{employees.map(e=><tr key={e.id}>
  <td>{e.id}</td><td>{e.name}</td><td>{e.department}</td><td>{e.designation}</td><td>{e.salary}</td>
  <td><button onClick={()=>onEdit(e)}>Edit</button><button onClick={()=>onDelete(e.id)}>Delete</button></td>
  </tr>)}</tbody></table>
}
