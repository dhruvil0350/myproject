
import React,{useEffect,useState} from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import EmployeeForm from './components/EmployeeForm';
import EmployeeTable from './components/EmployeeTable';
import Search from './components/Search';

export default function App(){
  const [employees,setEmployees]=useState([]);
  const [editing,setEditing]=useState(null);
  const [search,setSearch]=useState('');

  useEffect(()=>{
    const data=JSON.parse(localStorage.getItem('employees')||'[]');
    setEmployees(data);
  },[]);

  useEffect(()=>{
    localStorage.setItem('employees',JSON.stringify(employees));
  },[employees]);

  const saveEmployee=(emp)=>{
    if(editing){
      setEmployees(employees.map(e=>e.id===editing.id?emp:e));
      setEditing(null);
    }else{
      setEmployees([...employees,emp]);
    }
  };

  const deleteEmployee=(id)=>{
    if(window.confirm('Delete this employee?')){
      setEmployees(employees.filter(e=>e.id!==id));
    }
  };

  const filtered=employees.filter(e=>
    e.id.toLowerCase().includes(search.toLowerCase()) ||
    e.name.toLowerCase().includes(search.toLowerCase())
  );

  return <div className="container">
    <Header total={employees.length}/>
    <Search search={search} setSearch={setSearch}/>
    <EmployeeForm onSave={saveEmployee} editing={editing}/>
    <EmployeeTable employees={filtered} onEdit={setEditing} onDelete={deleteEmployee}/>
    <Footer/>
  </div>
}
