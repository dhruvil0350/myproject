function Home() {
  return (
    <div className="page">
      <div className="banner">
        <h1>Welcome to Student Portal</h1>
        <p>
          A simple and efficient platform for managing student information.
        </p>
      </div>

      <div className="home-content">
        <h2>Student Management Made Easy</h2>

        <p>
          Welcome to the Student Portal Application, a modern web-based system
          designed to simplify the process of managing student records. This
          portal allows users to register students, maintain their academic
          details, and view all registered students in a well-organized format.
        </p>

        <p>
          Using this application, you can easily store important information
          such as student name, enrollment number, branch, and semester. The
          portal provides a user-friendly interface with smooth navigation,
          responsive design, and efficient data management features.
        </p>

        <p>
          Our goal is to provide a convenient and reliable solution for
          educational institutions and learners to keep student information
          organized and accessible anytime.
        </p>
      </div>
    </div>
  );
}

export default Home;