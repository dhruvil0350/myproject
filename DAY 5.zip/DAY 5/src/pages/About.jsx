export default function About() {
  return (
    <div className="page">
      <h1>About Us</h1>
      <p>This portal helps manage student registration and records.</p>
	<p>
  The Student Portal Application is a user-friendly web application designed
  to manage student information efficiently. It allows students to register
  their details, including name, enrollment number, branch, and semester,
  while providing an organized view of all registered student records. The
  portal is built using React JS and React Router DOM to ensure smooth
  navigation between pages. Its responsive design makes it accessible on
  desktops, tablets, and mobile devices, offering a simple and effective
  solution for student data management.
</p>
    </div>
  );
}
