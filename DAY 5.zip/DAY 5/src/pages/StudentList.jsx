export default function StudentList({ students }) {
  return (
    <div className="page">
      <h1>Student List</h1>
      <h3>Total Registered Students: {students.length}</h3>
      <table>
        <thead>
          <tr>
            <th>Name</th><th>Enrollment</th><th>Branch</th><th>Semester</th>
          </tr>
        </thead>
        <tbody>
          {students.map((s, i) => (
            <tr key={i}>
              <td>{s.name}</td>
              <td>{s.enrollment}</td>
              <td>{s.branch}</td>
              <td>{s.semester}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
