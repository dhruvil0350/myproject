import { useState } from "react";

export default function StudentRegistration({ students, setStudents }) {
  const [formData, setFormData] = useState({ name:"", enrollment:"", branch:"", semester:"" });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setStudents([...students, formData]);
    setFormData({ name:"", enrollment:"", branch:"", semester:"" });
    alert("Student Registered Successfully");
  };

  return (
    <div className="page">
      <h1>Student Registration</h1>
      <form className="form" onSubmit={handleSubmit}>
        <input name="name" placeholder="Student Name" value={formData.name} onChange={handleChange} required />
        <input name="enrollment" placeholder="Enrollment Number" value={formData.enrollment} onChange={handleChange} required />
        <input name="branch" placeholder="Branch" value={formData.branch} onChange={handleChange} required />
        <input name="semester" placeholder="Semester" value={formData.semester} onChange={handleChange} required />
        <button type="submit">Register</button>
      </form>
    </div>
  );
}
