import { useState } from "react";


export default function App() {
  const [cart, setCart] = useState([]);
const [showCart, setShowCart] = useState(false);
const totalPrice = cart.reduce(
  (total, item) => total + item.price,
  0
);
const removeFromCart = (indexToRemove) => {
  setCart(
    cart.filter((_, index) => index !== indexToRemove)
  );
};
  const [search, setSearch] = useState("");
  const [selectedProduct, setSelectedProduct] = useState(null);
const [showContact, setShowContact] = useState(false);
  const products = [
    {
      name: "Watch",
      image: "/images/1.jpg",
      price: "1999"
    },
    {
      name: "Backpack",
      image: "/images/2.jpg",
      price: "599"
    },
    {
      name: "Shoes",
      image: "/images/3.jpg",
      price: "999"
    },
    {
      name: "Shirt",
      image: "/images/4.jpg",
      price: "499"
    },
    {
      name: "Gaming Keyboard",
      image: "/images/5.jpg",
      price: "999"
    },
    {
      name: "Gaming Mouse",
      image: "/images/6.jpg",
      price: "699"
    }
  ];

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(search.toLowerCase())
  );
  if (showContact) {
  return (
    <div>

      <header className="navbar">

        <div className="logo">
          <img
            src="/images/logo.png"
            alt="Shoply Logo"
            className="logo-img"
          />
          <h2>Shoply</h2>
        </div>

        <button
          className="cart-btn-nav"
          onClick={() => setShowContact(false)}
        >
          🏠 Home
        </button>

      </header>

      <div className="contact-page">

        <div className="contact-box">

          <div className="contact-left">

            <h1>Contact Us</h1>

            <p>
              We'd love to hear from you.
              Send us a message and we'll respond as soon as possible.
            </p>

            <input
              type="text"
              placeholder="Your Name"
            />

            <input
              type="email"
              placeholder="Your Email"
            />

            <textarea
              rows="5"
              placeholder="Your Message"
            ></textarea>

            <button>
              Send Message
            </button>

          </div>

          <div className="contact-right">

            <img
              src="/images/logo.png"
              alt="Shoply"
              className="contact-logo"
            />

            <h2>Shoply</h2>

            <p>📍 Palitana, India</p>

            <p>📞 +91 70464049484</p>

            <p>📧 support@shoply.com</p>

            <p>🕒 Mon - Sat | 9AM - 8PM</p>

          </div>

        </div>

      </div>

    </div>
  );
}
  if (selectedProduct) {
  return (
    <div>

      <header className="navbar">

        <div className="logo">
          <img
            src="/images/logo.png"
            alt="Shoply Logo"
            className="logo-img"
          />
          <h2>Shoply</h2>
        </div>

        <button
          className="cart-btn-nav"
          onClick={() => setSelectedProduct(null)}
        >
          ← Back
        </button>

      </header>

      <div className="product-page">

        <img
          src={selectedProduct.image}
          alt={selectedProduct.name}
          className="product-page-image"
        />

        <h1>{selectedProduct.name}</h1>

        <h2>₹{selectedProduct.price}</h2>

        <p>
          Premium quality product with modern design,
          excellent durability and fast delivery.
        </p>

        <button
          className="cart-btn"
          onClick={() =>
            setCart([...cart, selectedProduct])
          }
        >
          Add To Cart
        </button>

      </div>

    </div>
  );
}
if (showCart) {
  return (
    <div>

      {/* Navbar */}
      <header className="navbar">

        <div className="logo">
          <img
            src="/images/logo.png"
            alt="Shoply Logo"
            className="logo-img"
          />
          <h2>Shoply</h2>
        </div>

      

        <div className="nav-icons">
          <button
            className="cart-btn-nav"
            onClick={() => setShowCart(false)}
          >
            🏠 Home
          </button>
        </div>

      </header>

      {/* Cart Page */}
     <div className="cart-page">

  <h1>🛒 My Cart</h1>

  {cart.length === 0 ? (
    <h2>Your cart is empty 😔</h2>
  ) : (
    <>
      {cart.map((item, index) => (
        <div key={index} className="cart-item">

          <img
            src={item.image}
            alt={item.name}
            className="cart-image"
          />

          <div className="cart-details">
            <h3>{item.name}</h3>
            <p>₹{item.price}</p>

            <button
              className="delete-btn"
              onClick={() => removeFromCart(index)}
            >
              Delete
            </button>
          </div>

        </div>
      ))}

      <div className="cart-summary">
        <h2>Total: ₹{totalPrice}</h2>

        <button
          className="empty-cart-btn"
          onClick={() => setCart([])}
        >
          Empty Cart
        </button>
      </div>
    </>
  )}

</div>

    </div>
  );
}

  return (
    <div>

      {/* Navbar */}
      <header className="navbar">

        <div className="logo">
          <img
            src="/images/logo.png"
            alt="Shoply Logo"
            className="logo-img"
          />
          <h2>Shoply</h2>
        </div>

        <nav className="nav-links">
  <a
    href="#"
    onClick={() => setShowContact(true)}
  >
    Contact
  </a>
</nav>

        <div className="nav-icons">

          <input
            type="text"
            placeholder="Search products..."
            className="search-box"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <button
  className="cart-btn-nav"
  onClick={() => setShowCart(true)}
>
  🛒 Cart ({cart.length})
</button>

        </div>

      </header>

      {/* Hero Section */}
      <section className="hero">

        <div>
          <h1>Elevate Your Style This Summer</h1>

          <p>
            Discover premium fashion, accessories,
            and lifestyle products at unbeatable prices.
          </p>

          <button>
            Shop Now
          </button>
        </div>

      </section>

      {/* Featured Products */}
      <section className="featured">

        <h2>Featured Products</h2>

        <div className="grid">

          {filteredProducts.length > 0 ? (
            filteredProducts.map((p, i) => (

              <div key={i} className="card">

                <img
                  src={p.image}
                  alt={p.name}
                  className="img"
                />

                <h3>{p.name}</h3>

<p>₹{p.price}</p>

<button
  className="view-btn"
  onClick={() => setSelectedProduct(p)}
>
  View Product
</button>

<button
  className="cart-btn"
  onClick={() => setCart([...cart, p])}
>
  Add To Cart
</button>
              </div>

            ))
          ) : (
            <h3>😔 No products found</h3>
          )}

        </div>

      </section>

    </div>
  );
}