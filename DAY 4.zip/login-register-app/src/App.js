import { useState } from "react";
import Login from "./components/Login";
import Register from "./components/Register";
import "./App.css";

function App() {
  const [page, setPage] = useState("login");

  return (
    <div className="container">
      <button onClick={() => setPage("login")}>Login</button>
      <button onClick={() => setPage("register")}>Register</button>
      {page === "login" ? <Login /> : <Register />}
    </div>
  );
}

export default App;
