import { useState } from "react";

function Login() {
  const [data, setData] = useState({ email: "", password: "" });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!data.email || !data.password) {
      alert("All fields are required");
      return;
    }
    console.log("Login Data:", data);
    alert("Login Successful");
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Login</h2>
      <input type="email" placeholder="Email"
        onChange={(e) => setData({ ...data, email: e.target.value })} />
      <input type="password" placeholder="Password"
        onChange={(e) => setData({ ...data, password: e.target.value })} />
      <button type="submit">Login</button>
    </form>
  );
}

export default Login;
