import { useState } from "react";

function Register() {
  const [data, setData] = useState({
    name:"", email:"", mobile:"", password:"", confirmPassword:""
  });

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!data.name || !data.email || !data.mobile || !data.password || !data.confirmPassword) {
      alert("All fields are required");
      return;
    }

    if (!/\S+@\S+\.\S+/.test(data.email)) {
      alert("Invalid Email");
      return;
    }

    if (data.password !== data.confirmPassword) {
      alert("Passwords do not match");
      return;
    }

    console.log("Register Data:", data);
    alert("Registration Successful");
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Register</h2>
      <input type="text" placeholder="Full Name" onChange={(e)=>setData({...data,name:e.target.value})} />
      <input type="email" placeholder="Email" onChange={(e)=>setData({...data,email:e.target.value})} />
      <input type="text" placeholder="Mobile Number" onChange={(e)=>setData({...data,mobile:e.target.value})} />
      <input type="password" placeholder="Password" onChange={(e)=>setData({...data,password:e.target.value})} />
      <input type="password" placeholder="Confirm Password" onChange={(e)=>setData({...data,confirmPassword:e.target.value})} />
      <button type="submit">Register</button>
    </form>
  );
}

export default Register;
